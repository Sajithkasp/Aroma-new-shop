import type { Metadata } from 'next'
import ProductDetailClient from './ProductDetailClient'

export const dynamicParams = true
export const dynamic = 'force-dynamic'

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  return { title: `Product | ${slug}`, description: 'Product details from the Aroma catalogue.' }
}

export default async function ProductDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  return <ProductDetailClient slug={slug} />
}
