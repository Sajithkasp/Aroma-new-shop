'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function AdminLogin() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()

  useEffect(() => {
    let active = true
    supabase.auth.getSession().then(({ data }) => {
      if (!active || !data.session?.user) return
      const user = data.session.user
      const expected = (process.env.NEXT_PUBLIC_ADMIN_EMAIL || '').trim().toLowerCase()
      const verified = Boolean(user.email_confirmed_at || user.user_metadata?.email_verified === true)
      if (expected && verified && user.email?.trim().toLowerCase() === expected) router.replace('/admin/dashboard')
    })
    return () => { active = false }
  }, [router])

  const signIn = async () => {
    setLoading(true); setError('')
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/admin/login`, queryParams: { prompt: 'select_account' } }
    })
    if (error) { setError(error.message); setLoading(false) }
  }

  return <main className="min-h-screen flex items-center justify-center bg-neutral-950 text-white p-5"><section className="w-full max-w-sm rounded-2xl border border-neutral-800 bg-neutral-900 p-8 text-center"><h1 className="text-2xl font-semibold mb-2">Admin Login</h1><p className="text-sm text-neutral-400 mb-6">Sign in with your authorized Google account.</p>{error && <p role="alert" className="text-sm text-red-400 mb-4">{error}</p>}<button onClick={signIn} disabled={loading} className="w-full rounded-xl bg-amber-400 px-4 py-3 font-semibold text-black disabled:opacity-60">{loading ? 'Connecting…' : 'Continue with Google'}</button><a href="/" className="block mt-5 text-sm text-neutral-400 hover:text-white">Return to store</a></section></main>
}
