'use client'

import { useEffect, useState } from 'react'
import { usePathname, useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'

export default function AdminDashboardLayout({ children }: { children: React.ReactNode }) {
  const [allowed, setAllowed] = useState(false)
  const [checking, setChecking] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    let active = true
    const verify = async () => {
      const expected = (process.env.NEXT_PUBLIC_ADMIN_EMAIL || '').trim().toLowerCase()
      const { data } = await supabase.auth.getSession()
      const user = data.session?.user
      const verified = Boolean(user?.email_confirmed_at || user?.user_metadata?.email_verified === true)
      const ok = Boolean(expected && user?.email && verified && user.email.trim().toLowerCase() === expected)
      if (!active) return
      setAllowed(ok)
      setChecking(false)
      if (!ok && pathname !== '/admin/login') router.replace('/admin/login')
    }
    verify()
    const { data: listener } = supabase.auth.onAuthStateChange(() => { verify() })
    return () => { active = false; listener.subscription.unsubscribe() }
  }, [pathname, router])

  if (checking) return <main className="min-h-screen bg-neutral-950 text-neutral-300 flex items-center justify-center">Verifying administrator…</main>
  if (!allowed) return <main className="min-h-screen bg-neutral-950 text-neutral-300 flex items-center justify-center">Redirecting to secure login…</main>
  return children
}
