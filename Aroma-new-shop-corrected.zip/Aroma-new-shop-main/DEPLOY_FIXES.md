# AROMA project fixes — deployment notes

This patch keeps the existing Supabase tables and the existing Storage bucket named `media`; it does not add a table or run a database migration.

## Cloudflare Pages environment variables
Set these for both Production and Preview as appropriate:

- `NEXT_PUBLIC_SUPABASE_URL` — your existing Supabase project URL (`https://<project-ref>.supabase.co`)
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` — your project's publishable/anon key only; never use a service-role key in browser code
- `NEXT_PUBLIC_ADMIN_EMAIL` — the authorized administrator email

Redeploy after saving the variables. Enable Google under Supabase Authentication → Providers → Google, and add the deployed site's `/admin/login` and homepage callback URLs to Supabase's allowed redirect URLs.

## Existing database objects used
- `products` — product records
- `product_images` — product gallery rows (`product_id`, `image_url`, `alt_text`, `sort_order`, `is_primary`)
- Supabase Storage bucket `media` — uploaded product images, stored under `products/`

No migration is included because the project should reuse the existing tables. Product write operations require suitable Supabase RLS policies for authenticated administrator users, and Storage upload requires an authenticated policy for the `media` bucket. Verify those existing policies in Supabase before deployment; the browser app must not use a service-role key.

## Important limitation
The administrator email is configured through a public environment variable because the browser needs to compare the signed-in user's email to show the button. This is only a UI gate; database security must be enforced by Supabase RLS. The app checks for a verified Supabase session and removes the client-side passcode bypasses.
